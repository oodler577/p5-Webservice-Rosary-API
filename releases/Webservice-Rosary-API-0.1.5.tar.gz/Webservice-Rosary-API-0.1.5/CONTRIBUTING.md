If there were one million families praying the Rosary every day, the entire world would be saved.

-Pope Pius X
