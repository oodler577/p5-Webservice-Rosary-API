If there were one million families praying the Rosary every day, the entire world would be saved.

-Pope Pius X

https://github.com/user-attachments/assets/091eb27e-6187-440e-be4a-79d91a50887c

